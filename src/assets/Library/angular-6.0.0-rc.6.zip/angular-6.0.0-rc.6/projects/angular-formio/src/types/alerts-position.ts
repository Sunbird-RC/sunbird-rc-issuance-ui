export enum AlertsPosition {
  none,
  top,
  bottom,
  both
}
