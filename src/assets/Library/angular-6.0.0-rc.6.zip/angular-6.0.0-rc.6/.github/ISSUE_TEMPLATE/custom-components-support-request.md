---
name: Custom Components Support Request
about: Questions about Custom Components
title: "[Custom Components] "
labels: 'question, scope: community, scope: custom components'
assignees: ''

---

<!--
Thank you for reaching us regarding to Custom Components.
Please note that Angular wrapper for Custom Components is community build which also means you may get help from the community.

Before submitting your request, please read our Wiki page: https://github.com/formio/angular-formio/wiki/Custom-Components-with-Angular-Elements
-->
