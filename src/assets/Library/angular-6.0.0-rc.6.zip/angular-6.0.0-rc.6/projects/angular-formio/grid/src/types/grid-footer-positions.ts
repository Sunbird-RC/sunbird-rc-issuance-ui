export enum GridFooterPositions {
  bottom,
  top,
  both
}
